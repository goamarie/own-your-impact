# Start Here: My Career Brain

> Created with Own Your Impact by your good friend AnneMarie Fernandez.

This folder is my Personal Career Record: my skills, growth, wins in my own words, and the people who know my work. It's written in plain Markdown so any AI tool can read it.

## Two records, two homes
- **Internal Impact Record:** the detailed version (exact metrics, dashboards, names, links to proof). It lives in my employer's approved systems, not here.
- **Personal Career Record (this folder):** only information I'm authorized to keep and share. No customer names, no nonpublic numbers, no internal documents.

Putting something in a Markdown file or a personal AI doesn't make it mine. What makes it mine is that it's my own words, my own growth, and information I'm authorized to keep. Rounded or anonymized numbers can still be confidential.

## Who I am
*(3 sentences. Ask Claude to fill this in from your portfolio log.)*

## Roles and dates
| Company | Title | Dates | Scope |
| --- | --- | --- | --- |
|  |  |  |  |

## Top strengths
-
-
-

## My writing voice
*(How I sound: direct, warm, technical, playful... Add 2-3 sample sentences.)*

## What each folder holds
- `01-portfolio-log.md` – my personal running log. Newest entries on top.
- `02-wins/` – one file per accomplishment, in my own words.
- `03-proof/` – recognition, performance information, work samples, results, and public work I'm authorized to keep. `03-proof/INDEX.md` lists every item with what it shows and proves.
- `04-people.md` – references, mentees, partners, and how to reach them.
- `05-stories.md` – my best interview stories.
- `06-strengths-and-skills.md` – what I'm good at, with evidence.
- `07-directions.md` – career directions I'm exploring and what I'm testing.
- `08-prompts/` – every prompt from the kit, ready to reuse.
- `09-personal/` – optional: goals, life admin, side projects.
- `food-for-thought.md` – three reads on who owns your professional memory.

## Instructions for any AI reading this folder
- Use only what's in these files or what I tell you. Never invent accomplishments or numbers.
- Pull wins from `01-portfolio-log.md` and `02-wins/`; stories from `05-stories.md`.
- Write in my voice (above).
- Before drafting anything for a specific job or person, ask me who it's for and what I want them to do.
- When I share something new, give it back formatted for the right file, with the file name.
- Never ask me to paste internal company documents into this folder or a personal AI.
