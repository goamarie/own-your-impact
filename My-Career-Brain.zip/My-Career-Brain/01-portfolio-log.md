# Portfolio Log (personal version)

Active journaling, not hoarding: a few lines a week with context, in my own words, with nothing confidential. Newest entries on top. The detailed version lives in my work Project.

## Entry format
```
### YYYY-MM-DD – Short title
- Problem or opportunity:
- Baseline (generalized if needed):
- My contribution:
- Outcome:
- Business value:
- Who noticed:
- Evidence: where it's verified (kept at work, or public/authorized items in 03-proof/)
- Skills shown:
```

---

## Blind spots
One thing about me I don't see but need to know. Newest on top, with the evidence.

- YYYY-MM-DD – Agent: Underrated strength: ... / Pattern to watch: ... / Evidence: ...

### Quarterly human check
Once a quarter, in a 1:1, ask your manager, a skip-level, or a trusted peer (rotate them): "What is one thing about me you think I don't see, but should know?" Log it here next to the agent's answers. Where they agree, pay attention.

- YYYY-MQ – From [name, relationship]: ...

---

