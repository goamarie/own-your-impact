# Win: [short title]

**Date(s):**
**Role:**

## Problem or opportunity
## Baseline
*(Generalize anything confidential.)*
## My contribution
## Outcome
## Impact lens and number
*(Lens: volume, frequency, time, risk, reach, or judgment.)*
- Number:
- How sure: Measured / Estimated / Reported
- Math, if estimated: (minutes each time × people × times per week × weeks)
*(Exact figures stay in your internal record. Round and generalize here.)*
## Business value
## Evidence
*(Where it's verified. Detailed proof stays in approved work systems.)*

## Skills shown
-

## How I'd tell this in an interview (2-3 sentences)
