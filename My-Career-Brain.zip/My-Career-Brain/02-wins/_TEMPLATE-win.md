# Win: [short title]

**Date(s):**
**Role:**

## Problem or opportunity
## Baseline
*(Generalize anything confidential.)*
## My contribution
## Outcome
## Business value
## Evidence
*(Where it's verified. Detailed proof stays in approved work systems.)*

## Skills shown
-

## How I'd tell this in an interview (2-3 sentences)
