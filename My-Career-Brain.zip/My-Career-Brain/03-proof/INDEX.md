# Proof Index

Every item here gets one row. This is how any AI finds your evidence. Only items you're authorized to keep.

Naming: YYYY-MM-DD-subject.ext (e.g. 2026-11-06-conference-talk.mp4)

| File or link | Date | Project | What it shows | What it proves |
| --- | --- | --- | --- | --- |
| public-work/2026-11-06-conference-talk.mp4 | 2026-11-06 | Customer onboarding | My public talk on onboarding design | Presenting to large audiences; product storytelling |
