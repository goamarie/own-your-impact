# public-work

Links to launches, talks, posts, press, and your own public demos. Keep large videos in your personal cloud, not a code repository.
