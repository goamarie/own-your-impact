# recognition

Recognition you're authorized to keep, or your own summary of it (who, when, what for).
