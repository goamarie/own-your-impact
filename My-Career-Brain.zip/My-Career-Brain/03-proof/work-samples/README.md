# work-samples

Your own descriptions of work you built. Company files stay at work: describe the problem, your approach, and what shipped.
