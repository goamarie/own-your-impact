# People

| Name | Relationship | What they'd vouch for | Personal email / LinkedIn | Last contact |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
