# Strengths and Skills

| Strength or skill | Evidence (win or proof) | Depth |
| --- | --- | --- |
|  |  |  |
