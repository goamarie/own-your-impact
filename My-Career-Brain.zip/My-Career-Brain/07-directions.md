# Directions I'm Exploring

| Direction | Why it fits (evidence) | Small test | Status |
| --- | --- | --- | --- |
|  |  |  |  |
