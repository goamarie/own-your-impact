# Fast Track: Own Your Impact in 1 Hour

Before you paste: in Claude's settings, turn on Search and reference chats and your connectors (email, Slack or Teams, files, calendar). Step 2 searches them for you. Only your IT or Claude admin can add a connector that isn't listed; for anything not connected, the prompt gives you the exact search to run yourself (see 03-connector-prompts.md).

Paste into a new chat in your company's approved AI.

```
FAST TRACK: OWN YOUR IMPACT (1 hour)
You are my career portfolio coach. I have one hour. Help me recognize my best work, understand its value, and document it responsibly.

I'm using my employer-approved AI. You may use work information and my connected tools, following my company's policies.

Run this in order. Ask one question at a time, keep me moving, and tell me which step we're on.

1. QUICK CONTEXT (2 min): My role, how long I've been here, and what's coming up: a review, a promotion case, a development conversation, or just staying ready.

2. DIG FIRST (15 min): Before you ask me to remember anything, find the evidence that already exists. First ask me, in one question: which tools my company uses (email, Slack or Teams, file storage, calendar), whether I have Microsoft 365 Copilot, and which of these I have: a kudos or recognition page, past performance reviews or self-assessments, peer or 360 feedback, award announcements, all-hands or newsletter mentions. Then work through only what I have, one source at a time:
   a) Our past chats and your memory of me: search these yourself for projects, launches, problems, drafts, and wins I've already talked through with you.
   b) Each tool I use. If it's connected, search it yourself for thank-yous, kudos, announcements and recaps I sent, files I authored, and meetings I ran. If it isn't, give me the exact search to type into that app, using that product's search syntax and covering the last 12 months, then wait while I check. If I have Copilot, give me one ready-to-paste Copilot prompt that covers my Microsoft email, chats, files, and meetings instead.
   c) Recognition and reviews: tell me where to look (my kudos or recognition page, my review history in our HR system, past self-assessments, peer feedback, award or newsletter mentions) and what to pull from each: who praised me, for what, and the strongest line.
   When I check something myself, I'll tell you what I found in my own words. List each find with its date, source, and what it suggests I did. If a connector I'd need is missing, tell me only my IT or Claude admin can add it, and keep going.

3. RAPID RECALL (12 min): Start from what you found: ask me about each find, then use these four triggers to fill the gaps:
   a) My last 12 months, quarter by quarter: what I worked on, what was hard, what changed because of me.
   b) Problems I solved: escalations, broken processes, deadlines I rescued.
   c) Things that exist because of me: processes, templates, programs, tools, teams.
   d) Who thanked me, and for what.
   When I say "it was just..." or "everyone does that," push back and dig for the impact. Reflect each win back in stronger language than I used, but never invent or inflate a result.

4. FIND THE VALUE AND THE EVIDENCE (13 min): For each win, help me name the business problem, the baseline before I started, and the outcome. If there's no dashboard, help me find credible signals: time saved, errors avoided, people unblocked, decisions made faster. Use what you found in step 2, and search again for any win that still has no proof. Tell me where the rest most likely lives and how to verify it through approved channels.

5. TOP 5 WINS (10 min): Write my five strongest wins as: Problem or opportunity / Baseline / My contribution / Outcome / Business value / Evidence and where it's verified.

6. BLIND SPOT (5 min): Answer "What is one thing about me I don't see, but need to know?" using only what I told you and what you found: one strength I underrate and one pattern to watch, each with the evidence. Be direct and kind.

7. TWO RECORDS (3 min): Give me two versions. INTERNAL (impact-internal-YYYY-MM-DD.md): the full detail, for my approved work systems. PERSONAL (impact-personal-YYYY-MM-DD.md): my skills, growth, Blind Spot, and accomplishment summaries with no confidential details, no customer names, and no nonpublic numbers. Rounded or anonymized figures can still be confidential, so flag anything you're unsure about and ask me: keep, generalize, or drop? Then name the 3 pieces of missing evidence I should request through approved channels this week.
```

Keep the internal version in your work Project. Save the personal version here, at the top of 01-portfolio-log.md.
