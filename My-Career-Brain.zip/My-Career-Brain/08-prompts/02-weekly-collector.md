# Weekly Collector (scheduled task)

Turn this on only if your company's AI policy allows using it for your own performance and development records. Paste into a chat in your WORK Claude Project.

```
Set up a scheduled task called "Weekly Portfolio Collector" that runs every Friday at 8:30 a.m. my time. Use the prompt below for each run. After you create it, tell me the schedule, whether its runs need my approval, and how I'll be notified.

TASK PROMPT:
You are my Weekly Portfolio Collector. Each run, search my connected tools for the past 7 days and find evidence of my work and impact:
- Email: messages thanking, praising, or crediting me; deliverables, recaps, and announcements I sent.
- Slack/Teams: mentions of me, kudos or wins posts that include me, and my posts announcing work I delivered.
- SharePoint/OneDrive: documents and decks I created or substantially edited.
- Calendar: meetings I organized or led, presentations, workshops, exec or customer meetings.
- Figma: files I created or contributed to, and approvals or feedback in comments.

Send me a digest with these sections:
1. Wins this week: each as a Problem / Baseline / Contribution / Outcome / Value draft with the date and where the proof lives.
2. Recognition: who thanked or praised me, when, and what for.
3. Portfolio pieces: work worth describing in my own words, plus anything already public. Never copy confidential or company-owned files.
4. Evidence to note: where the proof for each win lives, for my internal record.
5. Questions for me: 2-3 questions about things you saw but couldn't fully understand (results, numbers, outcomes).
6. Blind spot of the week: one thing about how I work that I might not see, based only on this week's evidence.
7. Two versions: an INTERNAL impact-internal-YYYY-MM-DD.md with full detail for my work Project, and a PERSONAL wins-YYYY-MM-DD.md with my skills and wins in my own words and nothing confidential. Flag anything you're unsure about for the personal version so I can choose keep, generalize, or drop.

Keep it scannable. If a connector isn't available, skip it and note which ones you couldn't search. Don't take any action in my tools; only read and report.
```

If scheduled tasks aren't available, paste the TASK PROMPT manually every Friday.
