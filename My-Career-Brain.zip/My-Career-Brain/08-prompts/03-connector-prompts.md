# Connector Prompts (work Claude)

Run these in your company's approved AI. Replace [start date] with your start date.

- EMAIL: Search my email from [start date] to today for messages where people thanked me, praised my work, or credited me. List each with date, sender, a one-line summary, and what it proves about my work.
- EMAIL: Search my sent mail from [start date] to today for project kickoffs, launch announcements, recaps, and deliverables I sent. Group them by project and give me a timeline.
- SLACK/TEAMS: Search for messages that mention me or thank me, posts in kudos or wins channels that include me, and my own posts announcing work I delivered. List each with date, channel, and what it proves.
- SHAREPOINT/ONEDRIVE: Find documents, decks, and files I created or was the main editor on since [start date]. Group them by project and note which would make good portfolio write-ups.
- CALENDAR: Review my calendar since [start date]. List meetings I organized, presentations I gave, workshops I ran, and exec or customer meetings I led. Group by quarter.
- FIGMA: List the Figma files and projects I designed or contributed to since [start date], with dates, what each was for, and any approvals or feedback in comments. Don't copy or export designs; write a short description of each for my portfolio log.
- COPILOT: Find all emails and Teams messages since [start date] where someone thanked me, praised my work, or gave me credit. Summarize each with date, sender, and what it was about.
- OTHER SYSTEMS: Here's what I gathered from [system name]. Add it to my Internal Impact Record as entries: what it is, what it proves, which skill it shows, and a Problem / Baseline / Contribution / Outcome / Value bullet if there's enough detail. Then draft the personal version, flagging anything that may be confidential (keep, generalize, or drop?), and tell me what evidence seems to be missing.
