# Connector Prompts (work Claude)

Run these in your company's approved AI. Replace [start date] with your start date.

First, turn on Search and reference chats and your connectors in Claude's settings.

- PAST CHATS: Search our past chats and your memory of me from [start date] to today for projects, launches, problems I solved, and drafts I worked on with you. List each with date, a one-line summary, and what it proves about my work.

- EMAIL: Search my email from [start date] to today for messages where people thanked me, praised my work, or credited me. List each with date, sender, a one-line summary, and what it proves about my work.
- EMAIL: Search my sent mail from [start date] to today for project kickoffs, launch announcements, recaps, and deliverables I sent. Group them by project and give me a timeline.
- SLACK/TEAMS: Search for messages that mention me or thank me, posts in kudos or wins channels that include me, and my own posts announcing work I delivered. List each with date, channel, and what it proves.
- SHAREPOINT/ONEDRIVE: Find documents, decks, and files I created or was the main editor on since [start date]. Group them by project and note which would make good portfolio write-ups.
- CALENDAR: Review my calendar since [start date]. List meetings I organized, presentations I gave, workshops I ran, and exec or customer meetings I led. Group by quarter.
- FIGMA: List the Figma files and projects I designed or contributed to since [start date], with dates, what each was for, and any approvals or feedback in comments. Don't copy or export designs; write a short description of each for my portfolio log.
- COPILOT: Find all emails and Teams messages since [start date] where someone thanked me, praised my work, or gave me credit. Summarize each with date, sender, and what it was about.
- OTHER SYSTEMS: Here's what I gathered from [system name]. Add it to my Internal Impact Record as entries: what it is, what it proves, which skill it shows, and a Problem / Baseline / Contribution / Outcome / Value bullet if there's enough detail. Then draft the personal version, flagging anything that may be confidential (keep, generalize, or drop?), and tell me what evidence seems to be missing.


## No connector? Search it yourself

Run these in each app, scan the results, and tell Claude what you found in your own words. Set any date filter to the past 12 months.

**Gmail**
- Praise: `to:me (thanks OR "thank you" OR kudos OR "great job" OR shoutout) newer_than:1y`
- What you shipped: `from:me (launch OR launched OR recap OR kickoff OR announcing) newer_than:1y`

**Outlook**
- Praise: search `thanks OR kudos OR "great job" OR shoutout`, then use **Filters** to set the date range.
- What you shipped: open **Sent Items** and search `launch OR recap OR kickoff OR announcing`.

**Slack**
- Open **Activity → Mentions** and scroll back through the year.
- Search `thanks` plus your first name, and set the date filter.
- Search `from:@me in:#your-wins-channel` (use your team's kudos or wins channel).

**Microsoft Teams**
- Search `thanks`, `kudos`, or `great job`, then filter to Messages and set the date.
- Look for **Praise** badges people sent you.

**Google Drive**
- `owner:me type:document` (repeat with `type:presentation` and `type:spreadsheet`), then sort by last modified.

**SharePoint or OneDrive**
- In OneDrive, open **My files** and sort by Modified.
- In Microsoft 365 search, type `author:"Your Full Name"`.

**Calendar (Google or Outlook)**
- Search `review`, `readout`, `workshop`, `kickoff`, `QBR`, `training`, and `demo`. Note the meetings you organized or presented in.

**Microsoft 365 Copilot (paste this)**
```
Find emails, Teams messages, meetings, and files from the past 12 months where someone thanked me, praised my work, or credited me, plus documents and presentations I authored and meetings I organized or presented in. List each with date, source, a one-line summary, and a link.
```

## Recognition and reviews

These often hold your best proof, in other people's words.
- **Kudos or recognition page:** your company's intranet kudos wall or a recognition tool (such as Bonusly, Achievers, Workday, or Viva). Export or screenshot your received kudos.
- **Performance reviews:** your review history in your HR system (such as Workday, Lattice, or Culture Amp). Pull your manager's strongest lines and your ratings, where you're allowed to keep them.
- **Self-assessments:** your past ones are a ready-made list of wins.
- **Peer and 360 feedback:** who praised you, and for what.
- **Awards, all-hands, and newsletters:** any time you or your team were named.

Detailed copies stay in your work systems. Your personal record gets your own summary.
