# Reviews, Promotions, and Career Growth

- REVIEW: My performance review is coming up for [period]. Using my log, draft my self-assessment organized by [review categories]. Lead with impact and numbers, cite the proof for each point, include one growth area. Keep it in my voice.
- PROMOTION: I want to make the case for [target title or raise]. Build a one-page case: scope I already operate at, top results with numbers, evidence, and what I'd take on next. Flag gaps in proof.
- RESUME: Draft a resume for a [target role] in [industry]. Pull the strongest, most relevant accomplishments from my personal log and rewrite them for that audience. Every bullet needs a result, and nothing confidential.
- LINKEDIN: Write 3 headline options and an About section based on my personal log.
- STORIES: Give me my 3 best interview stories with proof, and which common questions each answers.
- CASE STUDY: Pick one project from my log and help me turn it into a case study I can share publicly: the problem, my approach, the result, and what I'd show as visuals. No company or customer names. Flag any numbers or details that could still identify the company or customer, even rounded or anonymized, and remind me to check with my manager before publishing.
- RECONNECT: List the people I should stay in touch with, why each matters, and a short natural message for each.
- GAP CHECK: Where is my evidence weakest? What claims lack evidence, and what should I request through approved channels this month?
- START-HERE: Using my personal log, write my 00-START-HERE.md: who I am in 3 sentences, roles and dates, top strengths, my writing voice, and instructions for any AI reading this folder.
