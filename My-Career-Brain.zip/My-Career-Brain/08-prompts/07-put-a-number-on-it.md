# Put a Number on It

Most work never shows up on a dashboard, but you can still give it a credible number. Pick a lens, count what you can, estimate the rest honestly, and label how sure you are. The three prompts below are for when you need them, not a schedule.

## Six impact lenses

| Lens | The question | Proxy metrics | Example |
| --- | --- | --- | --- |
| Volume | How much do you handle? | Requests, reviews, approvals, documents, tickets | Reviewed about 40 contracts a quarter |
| Frequency | How often, and how steadily? | Per week, recurring cadences, cycles run without a miss | Ran the weekly release check 48 weeks straight |
| Time | Whose time did you save, and how much? | Hours saved, turnaround cut, cycle time | Cut intake triage from 3 days to 1 |
| Risk | What didn't go wrong because of you? | Issues caught, escalations prevented, deadlines held | Caught 6 pricing errors before customers saw them |
| Reach | Who relied on it? | Teams, people, managers, clients served | Template used by 5 teams across 2 regions |
| Judgment | What couldn't be templated or handed off? | Decisions influenced, recommendations adopted | Recommended the vendor switch leadership approved |

*Lenses adapted from Christian Lovell's advice on proxy metrics.*

## Napkin math, shown

time saved = minutes each time × people × times per week × weeks

Example: 20 minutes × 8 people × 2 times a week × 40 weeks = about 213 hours a year.

## Label every number
- **Measured:** from a system, report, or dashboard.
- **Estimated:** your napkin math, inputs shown.
- **Reported:** what someone else said (a manager, a customer, a recap).

An honest estimate holds up in a review. One inflated number makes a reviewer doubt all the others. Exact figures go in your internal record; your personal record gets rounded, generalized versions.

## Count It For Me (before a review or promotion case, about 20 minutes)
```
COUNT IT FOR ME
Search my connected tools (calendar, sent mail, Slack or Teams, files) for the last 90 days. Count the recurring work I do and group it by category: meetings I ran, reviews or approvals I gave, requests I answered, documents I created, fixes or escalations I handled, people I onboarded or trained.

Give me a table: Category / Count / Per week / Example / The exact search you used.
Then:
1. Flag the 3 categories that show the most demand for my role.
2. For each one, estimate time saved or problems prevented using minutes × people × frequency. Show the math and label each number Measured, Estimated, or Reported.
3. Tell me which numbers a skeptical manager would challenge, and what evidence would hold up.
4. Write a PERSONAL version with rounded, generalized figures and no internal names. Ask me before keeping anything you're unsure about.

If a tool isn't connected, give me the exact search to run in that app and wait for my answer.
```

## The two-weeks-gone test
```
If I disappeared for two weeks with no handoff, what would break, slow down, or go wrong, and who would notice first? Ask me one question at a time about my recurring work, the people who come to me, and the things I check that no one else does. Then turn each answer into a win with its lens (Reach or Risk), a proxy metric, and a confidence label.
```

## Decisions count too
When someone acts on your recommendation, log it as a win under the Judgment lens. Come back in 30 to 90 days and add what happened.

## The skeptical-manager check (before any review, promotion case, or resume)
```
Act as a skeptical manager reviewing my impact claims below. For each number: is it Measured, Estimated, or Reported? Would you believe it? What would you push back on, and what evidence would change your mind? Then rewrite any claim that overreaches so it's still strong but fully defensible. Never inflate a result.
```
