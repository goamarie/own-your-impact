# Personal

Optional: goals, life admin, side projects. Same format, same AI.
