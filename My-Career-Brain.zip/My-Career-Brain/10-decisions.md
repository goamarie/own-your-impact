# Decision Log

Influence is the hardest work to prove because the payoff shows up later. When someone acts on your recommendation, add a line. Come back in 30 to 90 days and fill in what happened. Personal version: no customer names, no internal project names, no nonpublic numbers.

| Date | Decision | My input | Who acted on it | What happened (30-90 days later) |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
